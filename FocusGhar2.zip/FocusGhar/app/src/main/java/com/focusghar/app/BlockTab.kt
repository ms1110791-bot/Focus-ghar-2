package com.focusghar.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val DNS_HOST = "dns.adguard-dns.com"

private fun accOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return s.contains(BlockService::class.java.name)
}

private fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format("%02d:%02d", s / 60, s % 60)
}

@Composable
private fun Seg(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, enabled = enabled) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled) { Text(label) }
    }
}

@Composable
fun BlockTab(p: SharedPreferences) {
    val ctx = LocalContext.current
    var master by remember { mutableStateOf(p.getBoolean("master", true)) }
    var yt by remember { mutableStateOf(p.getBoolean("yt", true)) }
    var ig by remember { mutableStateOf(p.getBoolean("ig", true)) }
    var red by remember { mutableStateOf(p.getBoolean("redirect", true)) }
    var counter by remember { mutableStateOf(p.getBoolean("count", true)) }
    var brainOn by remember { mutableStateOf(p.getBoolean("brain", false)) }
    var mode by remember { mutableStateOf(p.getString("mode", "limit") ?: "limit") }
    var limit by remember { mutableStateOf(p.getInt("limit", 20)) }
    var strict by remember { mutableStateOf(p.getBoolean("strict", true)) }
    var debug by remember { mutableStateOf(p.getBoolean("debug", false)) }
    var focusUntil by remember { mutableLongStateOf(p.getLong("focusUntil", 0L)) }
    var pauseUntil by remember { mutableLongStateOf(p.getLong("pauseUntil", 0L)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showApps by remember { mutableStateOf(false) }
    var ids by remember { mutableStateOf("") }

    val tick = UiBus.tick
    val acc = remember(tick) { accOn(ctx) }
    // Reel counts are refreshed every time the app comes to the front.
    val today = remember(tick) { Data.reels(p, Data.today()) }
    val week = remember(tick) { Data.weekReels(p) }
    // Recomputed on every recomposition, so a changed limit is reflected at once.
    val locked = Prefs.locked(p)

    // The timer only runs while focus/pause is active; otherwise nothing is running.
    LaunchedEffect(focusUntil, pauseUntil) {
        while (focusUntil > System.currentTimeMillis() || pauseUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(1000)
        }
        now = System.currentTimeMillis()
    }

    fun putB(k: String, v: Boolean) = p.edit().putBoolean(k, v).apply()
    fun putL(k: String, v: Long) = p.edit().putLong(k, v).apply()

    val focusing = focusUntil > now
    val pausing = pauseUntil > now

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(
            "Focus Ghar",
            if (focusing) "Focus mode is on 🔥" else "Block reels. Stop sneaky redirects.",
            R.drawable.ic_logo
        )

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            if (!acc) {
                Panel {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚠️ Permission needed", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "Focus Ghar uses Android's Accessibility Service only to notice Shorts/Reels " +
                                "screens and apps opened by ads, then it presses Back. " +
                                "Nothing on your screen is stored or sent anywhere.",
                            fontSize = 14.sp
                        )
                        Button(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Open settings") }
                    }
                }
            }

            if (locked) {
                Panel {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("🔒 Locked until tomorrow", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "You reached your daily limit of $limit. Shorts/Reels stay blocked " +
                                "and the block settings are frozen until midnight.",
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // ---- Reel counter + brain ----
            if (counter) {
                val total = today.first + today.second
                val level = (total / maxOf(limit, 1).toFloat()).coerceIn(0f, 1f)
                val mood = when {
                    level < 0.25f -> "Fresh brain 🧠"
                    level < 0.5f -> "Getting foggy 😵"
                    level < 0.9f -> "Brain rot loading… 🥴"
                    else -> "Fully fried 💀"
                }
                Panel {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Brain(level, Modifier.size(110.dp))
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Shorts/Reels watched today", fontSize = 13.sp)
                            Text("$total", fontSize = 44.sp, fontWeight = FontWeight.Bold)
                            Text(mood, fontWeight = FontWeight.SemiBold)
                            Text(
                                "YouTube ${today.first} · Instagram ${today.second} · 7 days $week" +
                                    if (mode == "limit") " · limit $limit/day" else "",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            // ---- Block style: limit or instant ----
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🧭 Block style", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        if (mode == "limit") {
                            "Limit mode: you can watch a few. Warnings start at 3 of every 5, " +
                                "YouTube/Instagram is closed on every 5th reel, and at $limit reels " +
                                "Shorts/Reels are locked for the day."
                        } else {
                            "Instant mode: Shorts/Reels close as soon as they open."
                        },
                        fontSize = 13.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Seg("Limit", mode == "limit", !locked) {
                            mode = "limit"
                            p.edit().putString("mode", "limit").apply()
                        }
                        Seg("Instant", mode == "instant", !locked) {
                            mode = "instant"
                            p.edit().putString("mode", "instant").apply()
                        }
                    }
                    if (mode == "limit") {
                        Text("Daily limit (reels per day)", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(10, 20, 25).forEach { n ->
                                Seg("$n", limit == n, !locked) {
                                    limit = n
                                    p.edit().putInt("limit", n).apply()
                                }
                            }
                        }
                    }
                }
            }

            // ---- Focus mode ----
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎯 Focus mode", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (focusing) {
                        Text(clock(focusUntil - now), fontSize = 44.sp, fontWeight = FontWeight.Bold)
                        Text("Instant block is forced on for every app", fontSize = 13.sp)
                        Button(onClick = {
                            focusUntil = 0L
                            putL("focusUntil", 0L)
                        }) { Text("Stop") }
                    } else {
                        Text("One tap turns on instant blocking, with a timer", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(25, 60, 120).forEach { m ->
                                Button(onClick = {
                                    val t = System.currentTimeMillis() + m * 60_000L
                                    focusUntil = t
                                    putL("focusUntil", t)
                                }) { Text("$m min") }
                            }
                        }
                    }
                }
            }

            // ---- ON/OFF buttons ----
            Panel {
                Column {
                    ToggleRow("▶️", "YouTube Shorts control", "On = limit/block applies to Shorts", yt, enabled = !locked) {
                        yt = it
                        putB("yt", it)
                    }
                    ToggleRow("📸", "Instagram Reels control", "On = limit/block applies to Reels", ig, enabled = !locked) {
                        ig = it
                        putB("ig", it)
                    }
                    ToggleRow("🔗", "Block redirects", "If an ad opens Chrome/Play Store/another app, go back", red, enabled = !locked) {
                        red = it
                        putB("redirect", it)
                    }
                    if (mode == "limit") {
                        ToggleRow("🔐", "Strict lock", "After the daily limit, nothing can be switched off until tomorrow", strict, enabled = !locked) {
                            strict = it
                            putB("strict", it)
                        }
                    }
                    ToggleRow("📊", "Reel counter", "Show the count card (limits always count)", counter) {
                        counter = it
                        putB("count", it)
                    }
                    ToggleRow("🧠", "Floating brain", "Small brain with your live count while you watch Shorts/Reels", brainOn) {
                        brainOn = it
                        putB("brain", it)
                    }
                    ToggleRow("⚡", "App enabled", "Off = everything stops", master, enabled = !locked) {
                        master = it
                        putB("master", it)
                    }
                }
            }

            // ---- Pause ----
            if (!locked) {
                Panel {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⏸️ Short break", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        if (pausing) {
                            Text("Time left: ${clock(pauseUntil - now)}", fontSize = 14.sp)
                            Button(onClick = {
                                pauseUntil = 0L
                                putL("pauseUntil", 0L)
                            }) { Text("Resume blocking") }
                        } else {
                            Text("Want to watch Shorts/Reels? Pause blocking for a bit (reels still get counted)", fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(15, 30).forEach { m ->
                                    OutlinedButton(onClick = {
                                        val t = System.currentTimeMillis() + m * 60_000L
                                        pauseUntil = t
                                        putL("pauseUntil", t)
                                    }) { Text("$m min") }
                                }
                            }
                        }
                    }
                }
            }

            OutlinedButton(onClick = { showApps = true }, modifier = Modifier.fillMaxWidth()) {
                Text("✅ Apps allowed to open")
            }

            // ---- Ads in other apps ----
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🚫 Ads in other apps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        "Ads inside YouTube and Instagram come from the same servers as the videos, " +
                            "so no app can remove them. For ads in most other apps, use Android's " +
                            "Private DNS: Settings → search \"Private DNS\" → choose the hostname option " +
                            "→ paste:",
                        fontSize = 13.sp
                    )
                    Text(DNS_HOST, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            copyText(ctx, DNS_HOST)
                            Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                        OutlinedButton(onClick = {
                            try {
                                ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "Open Settings and search Private DNS", Toast.LENGTH_LONG).show()
                            }
                        }) { Text("Open settings") }
                    }
                }
            }

            // ---- Debug ----
            Panel {
                Column {
                    ToggleRow("🛠️", "Debug mode", "If blocking doesn't work, show screen IDs", debug) {
                        debug = it
                        putB("debug", it)
                    }
                    if (debug) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Open YouTube/Instagram, go to a Short/Reel, come back here and tap Refresh.",
                                fontSize = 12.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { ids = p.getString("last_ids", "") ?: "" }) {
                                    Text("Refresh")
                                }
                                OutlinedButton(onClick = {
                                    copyText(ctx, ids)
                                    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                }) { Text("Copy") }
                            }
                            if (ids.isNotEmpty()) Text(ids, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showApps) AllowedDialog(p) { showApps = false }
}

@Composable
private fun AllowedDialog(p: SharedPreferences, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var sel by remember { mutableStateOf(Prefs.allowed(p).toSet()) }

    // The app list is built in the background so the UI never freezes.
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .filter { it.second != ctx.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
        title = { Text("Allowed apps") },
        text = {
            Column {
                Text(
                    "Let these apps open from YouTube/Instagram (for example WhatsApp sharing).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(8.dp))
                val list = apps
                if (list == null) {
                    CircularProgressIndicator()
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { (label, pkg) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        sel = if (pkg in sel) sel - pkg else sel + pkg
                                        p.edit().putStringSet("allowed", HashSet(sel)).apply()
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = pkg in sel, onCheckedChange = null)
                                Text(label, modifier = Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                }
            }
        }
    )
}
