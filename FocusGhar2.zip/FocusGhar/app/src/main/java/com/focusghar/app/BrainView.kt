package com.focusghar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import androidx.core.graphics.ColorUtils

/** Same brain as the in-app Brain(), drawn with a plain View so the floating overlay can use it. */
class BrainView(ctx: Context) : View(ctx) {

    var level: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = ColorUtils.blendARGB(0xFFFF8FB1.toInt(), 0xFF8A9A5B.toInt(), level)
        val dark = ColorUtils.blendARGB(0xFFD6568A.toInt(), 0xFF4B5A33.toInt(), level)

        fill.color = base
        canvas.drawOval(RectF(w * 0.06f, h * 0.14f, w * 0.54f, h * 0.86f), fill)
        canvas.drawOval(RectF(w * 0.46f, h * 0.14f, w * 0.94f, h * 0.86f), fill)

        line.color = dark
        line.strokeWidth = w * 0.02f
        canvas.drawLine(w * 0.5f, h * 0.2f, w * 0.5f, h * 0.82f, line)
        listOf(0.27f to 0.36f, 0.73f to 0.36f, 0.30f to 0.62f, 0.70f to 0.62f).forEach { (x, y) ->
            val r = RectF(w * x - w * 0.08f, h * y - w * 0.08f, w * x + w * 0.08f, h * y + w * 0.08f)
            canvas.drawArc(r, 200f, 230f, false, line)
        }

        if (level > 0.3f) {
            fill.color = dark
            fill.alpha = 140
            canvas.drawCircle(w * 0.34f, h * 0.5f, w * 0.04f, fill)
            canvas.drawCircle(w * 0.66f, h * 0.45f, w * 0.03f, fill)
        }
        if (level > 0.6f) {
            line.strokeWidth = w * 0.016f
            canvas.drawLine(w * 0.64f, h * 0.2f, w * 0.58f, h * 0.36f, line)
            canvas.drawLine(w * 0.58f, h * 0.36f, w * 0.64f, h * 0.46f, line)
            canvas.drawLine(w * 0.3f, h * 0.76f, w * 0.38f, h * 0.64f, line)
        }
    }
}
