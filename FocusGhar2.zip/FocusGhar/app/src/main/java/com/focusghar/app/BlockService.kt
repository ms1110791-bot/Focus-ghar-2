package com.focusghar.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Blocks Shorts/Reels and unwanted redirects, counts the reels you watch,
 * and runs "limit mode": warnings, close every 5 reels, lock at the daily limit.
 * Warnings and the floating brain are accessibility overlays, so no extra permission is needed.
 */
class BlockService : AccessibilityService() {

    private val yt = "com.google.android.youtube"
    private val ig = "com.instagram.android"

    // View IDs of the Shorts/Reels player. They can change when YouTube/Instagram update;
    // Debug mode in the app shows the current IDs.
    private val ytIds = listOf(
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_watch_fragment_root"
    )
    private val igIds = listOf(
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/clips_swipe_refresh_container"
    )

    private val red = 0xEEB3261E.toInt()
    private val orange = 0xEEE0762B.toInt()

    private lateinit var p: SharedPreferences
    private var neutral: Set<String> = emptySet()
    private var ignored: Set<String> = emptySet()
    private var ime: Set<String> = emptySet()
    private var foreground: String? = null
    private var inShorts = false
    private var lastCheck = 0L
    private var lastCount = 0L
    private var lastBack = 0L
    private var backCount = 0
    private var lastRedirect = 0L

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var brainBox: LinearLayout? = null
    private var brainView: BrainView? = null
    private var brainText: TextView? = null
    private var banner: TextView? = null
    private val hideBannerRunnable = Runnable { hideBanner() }
    private var cutPending = false
    private var justCut = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        p = Prefs.sp(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshSets()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hideBrain()
        hideBanner()
        super.onDestroy()
    }

    private fun refreshSets() {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val home = packageManager.queryIntentActivities(homeIntent, 0).map { it.activityInfo.packageName }
        // System screens and our own overlays never count as "another app opened".
        ignored = setOf(
            "com.android.systemui",
            "android",
            "com.google.android.gms",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.google.android.packageinstaller",
            packageName
        )
        neutral = ignored + home
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        ime = imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val ev = e ?: return
        val pkg = ev.packageName?.toString() ?: return
        val type = ev.eventType

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) onWindow(pkg)

        // Only YouTube/Instagram events go further; everything else is dropped early to stay fast.
        if (pkg != yt && pkg != ig) return
        val scroll = type == AccessibilityEvent.TYPE_VIEW_SCROLLED
        if (!scroll &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return

        // Master switch OFF stops everything, except the strict lock after the daily limit.
        if (!p.getBoolean("master", true) && !Prefs.locked(p)) return

        val now = SystemClock.uptimeMillis()
        val limited = Prefs.enforced(p) && (if (pkg == yt) Prefs.yt(p) else Prefs.ig(p))
        val limitMode = Prefs.limitMode(p)
        val countOn = p.getBoolean("count", true)
        val brainOn = p.getBoolean("brain", false)
        val debug = p.getBoolean("debug", false)
        val needCount = countOn || brainOn || (limited && limitMode)
        if (!limited && !needCount && !debug) return

        if (scroll) {
            // A swipe inside Shorts/Reels = next video. Only needed for counting.
            if (!needCount || (limited && !limitMode) || now - lastCount < 900) return
        } else {
            if (now - lastCheck < 350) return
            lastCheck = now
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        if (debug && !scroll) {
            val found = linkedSetOf<String>()
            collect(root, found, 0)
            p.edit().putString("last_ids", pkg + "\n" + found.joinToString("\n")).apply()
        }

        val ids = if (pkg == yt) ytIds else igIds
        val hit = ids.any { root.findAccessibilityNodeInfosByViewId(it)?.isNotEmpty() == true }

        if (!hit) {
            if (!scroll) {
                inShorts = false
                hideBrain()
            }
            return
        }

        val before = Prefs.total(p)
        val limit = Prefs.limit(p)

        // Instant mode, focus mode, or daily limit reached: close it right away.
        if (limited) {
            val instant = !limitMode || Prefs.focusOn(p)
            if (instant || before >= limit) {
                val msg = if (limitMode && before >= limit) {
                    "🔒 Daily limit reached. Shorts/Reels are locked until tomorrow."
                } else {
                    "Shorts/Reels blocked 🚫"
                }
                block(now, msg)
                return
            }
        }

        // Count this reel: a new Shorts/Reels screen, or a swipe inside it.
        var counted = false
        if (needCount && (!inShorts || scroll) && now - lastCount >= 900) {
            lastCount = now
            Data.addReel(p, pkg == yt)
            counted = true
        }
        inShorts = true

        val total = if (counted) before + 1 else before
        if (brainOn) showBrain(total, limit, limitMode) else hideBrain()
        if (counted && limited && limitMode) onCounted(total, limit)
    }

    /** Limit mode: warn near every 5th reel, close on it, lock at the daily limit. */
    private fun onCounted(total: Int, limit: Int) {
        val step = Prefs.STEP
        val next = minOf((total / step + 1) * step, limit)
        when {
            total >= limit ->
                startCut("🔒 $total Shorts/Reels today. Daily limit reached. Closing for the day.")
            total % step == 0 ->
                startCut("⚠️ $total watched. Closing in 3 seconds. Next stop: $next.")
            justCut && !cutPending -> {
                justCut = false
                showBanner("⚠️ You've already watched $total today. Next stop at $next.", 3500, orange)
            }
            total % step >= step - 2 ->
                showBanner("⚠️ $total watched. Closing at $next. Stop now.", 2500, orange)
        }
    }

    /** Show a warning, then send YouTube/Instagram to the background. */
    private fun startCut(msg: String) {
        if (cutPending) return
        cutPending = true
        justCut = true
        showBanner(msg, 3200, red)
        handler.postDelayed({
            cutPending = false
            if (inShorts) performGlobalAction(GLOBAL_ACTION_HOME)
        }, 3000)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (n == null || depth > 25 || out.size > 80) return
        n.viewIdResourceName?.let { out.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun block(now: Long, msg: String) {
        if (now - lastBack < 700) return
        backCount = if (now - lastBack < 3000) backCount + 1 else 1
        lastBack = now
        if (backCount >= 3) {
            backCount = 0
            performGlobalAction(GLOBAL_ACTION_HOME)
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        showBanner(msg, 2200, red)
    }

    /** A new window opened: if another app opened right after YouTube/Instagram, send the user back. */
    private fun onWindow(pkg: String) {
        if (pkg in ignored || pkg in ime) return
        val prev = foreground
        foreground = pkg
        if (prev != pkg) {
            inShorts = false
            if (pkg != yt && pkg != ig) hideBrain()
        }
        if (prev == null || prev == pkg) return
        if (prev != yt && prev != ig) return
        if (pkg == yt || pkg == ig) return
        if (!Prefs.enforced(p) || !Prefs.redirect(p)) return
        if (pkg in neutral || pkg in Prefs.allowed(p)) return

        val now = SystemClock.uptimeMillis()
        if (now - lastRedirect < 1200) return
        lastRedirect = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        showBanner("Redirect blocked ✋", 2000, red)
    }

    // ------------------------------------------------------------------
    // Overlays (TYPE_ACCESSIBILITY_OVERLAY needs no "display over other apps" permission)
    // ------------------------------------------------------------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams() = WindowManager.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun showBanner(text: String, ms: Long, bg: Int) {
        val w = wm ?: return
        hideBanner()
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = dp(18).toFloat()
            }
        }
        val lp = overlayParams().apply {
            width = (resources.displayMetrics.widthPixels * 0.9f).toInt()
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(90)
        }
        try {
            w.addView(tv, lp)
            banner = tv
            handler.postDelayed(hideBannerRunnable, ms)
        } catch (e: Exception) {
            banner = null
        }
    }

    private fun hideBanner() {
        handler.removeCallbacks(hideBannerRunnable)
        val b = banner ?: return
        banner = null
        try {
            wm?.removeView(b)
        } catch (e: Exception) {
        }
    }

    private fun showBrain(total: Int, limit: Int, limitMode: Boolean) {
        val w = wm ?: return
        if (brainBox == null) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                alpha = 0.92f
            }
            val bv = BrainView(this)
            box.addView(bv, LinearLayout.LayoutParams(dp(54), dp(54)))
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(2), dp(10), dp(2))
                background = GradientDrawable().apply {
                    setColor(0xCC000000.toInt())
                    cornerRadius = dp(12).toFloat()
                }
            }
            box.addView(
                tv,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2) }
            )
            val lp = overlayParams().apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                x = dp(4)
            }
            try {
                w.addView(box, lp)
            } catch (e: Exception) {
                return
            }
            brainBox = box
            brainView = bv
            brainText = tv
        }
        brainView?.level = total / maxOf(limit, 1).toFloat()
        brainText?.text = if (limitMode) "$total/$limit" else "$total"
    }

    private fun hideBrain() {
        val b = brainBox ?: return
        brainBox = null
        brainView = null
        brainText = null
        try {
            wm?.removeView(b)
        } catch (e: Exception) {
        }
    }
}
