package com.focusghar.app

import android.content.SharedPreferences
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun YearTab(p: SharedPreferences) {
    val ctx = LocalContext.current
    var goals by remember { mutableStateOf<List<Goal>?>(null) }
    var newGoal by remember { mutableStateOf("") }
    var delIdx by remember { mutableIntStateOf(-1) }

    LaunchedEffect(Unit) {
        goals = withContext(Dispatchers.IO) { Data.goals(p) }
    }

    val list = goals

    fun save(l: List<Goal>) {
        goals = l
        Data.saveGoals(p, l)
    }

    fun addGoal() {
        val t = newGoal.trim()
        val cur = list ?: return
        if (t.isEmpty()) return
        save(cur + Goal(t))
        newGoal = ""
    }

    Column(Modifier.fillMaxSize()) {
        Header("Yearly goals", "What you want this year, and what you did today", R.drawable.ic_sec_year)

        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Panel {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newGoal,
                                onValueChange = { newGoal = it },
                                label = { Text("New goal (e.g. finish 10 courses)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { addGoal() })
                            )
                            Button(onClick = { addGoal() }) { Text("Add goal") }
                        }
                    }
                }

                itemsIndexed(list) { i, g ->
                    GoalCard(
                        g = g,
                        onLog = { e ->
                            save(list.mapIndexed { j, x -> if (j == i) x.copy(logs = x.logs + e) else x })
                        },
                        onDelete = { delIdx = i }
                    )
                }

                item {
                    Button(
                        onClick = { sendToClaude(ctx, Data.export(p)) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🤖 Talk to Claude (copies your data)") }
                }
            }
        }
    }

    if (delIdx >= 0 && list != null && delIdx < list.size) {
        AlertDialog(
            onDismissRequest = { delIdx = -1 },
            title = { Text("Delete goal?") },
            text = { Text("\"${list[delIdx].title}\" and everything you logged for it will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                    val k = delIdx
                    delIdx = -1
                    save(list.filterIndexed { j, _ -> j != k })
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { delIdx = -1 }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GoalCard(g: Goal, onLog: (Entry) -> Unit, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    var mins by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val total = g.logs.sumOf { it.min }
    val days = g.logs.map { it.date }.distinct().size

    Panel {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    g.title,
                    modifier = Modifier.weight(1f),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(if (open) "▲" else "▼")
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "⏱ ${total / 60}h ${total % 60}m · $days days",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            if (open) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = mins,
                        onValueChange = { mins = it.filter { c -> c.isDigit() }.take(4) },
                        label = { Text("Minutes") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(110.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("What did you do today?") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    val m = mins.toIntOrNull() ?: 0
                    if (m > 0 || note.isNotBlank()) {
                        onLog(Entry(Data.today(), m, note.trim()))
                        mins = ""
                        note = ""
                    }
                }) { Text("Save today's work") }

                if (g.logs.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    g.logs.takeLast(5).reversed().forEach {
                        Text("${it.date} · ${it.min} min · ${it.note}", fontSize = 12.sp)
                    }
                }
                TextButton(onClick = onDelete) { Text("🗑️ Delete goal") }
            }
        }
    }
}
