package com.focusghar.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Blocker ki settings. Service aur UI dono yahi SharedPreferences padhte hain (sab phone me, koi server nahi). */
object Prefs {
    const val NAME = "focus_prefs"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    private fun now() = System.currentTimeMillis()

    fun focusOn(p: SharedPreferences) = p.getLong("focusUntil", 0L) > now()
    fun paused(p: SharedPreferences) = p.getLong("pauseUntil", 0L) > now()

    /** Master ON ho aur (focus chal raha ho ya pause na ho). */
    fun active(p: SharedPreferences) =
        p.getBoolean("master", true) && (focusOn(p) || !paused(p))

    /** In limit mode, Shorts/Reels are closed after every STEP reels. */
    const val STEP = 5

    fun limitMode(p: SharedPreferences) = p.getString("mode", "limit") == "limit"
    fun limit(p: SharedPreferences) = p.getInt("limit", 20)
    fun strict(p: SharedPreferences) = p.getBoolean("strict", true)

    fun total(p: SharedPreferences): Int {
        val r = Data.reels(p, Data.today())
        return r.first + r.second
    }

    /** Strict lock: daily limit reached, so everything is forced ON until midnight. */
    fun locked(p: SharedPreferences) = limitMode(p) && strict(p) && total(p) >= limit(p)

    fun enforced(p: SharedPreferences) = locked(p) || active(p)

    // Focus mode and the strict lock force the blocks ON.
    fun yt(p: SharedPreferences) = locked(p) || focusOn(p) || p.getBoolean("yt", true)
    fun ig(p: SharedPreferences) = locked(p) || focusOn(p) || p.getBoolean("ig", true)
    fun redirect(p: SharedPreferences) = locked(p) || focusOn(p) || p.getBoolean("redirect", true)

    fun allowed(p: SharedPreferences): Set<String> =
        p.getStringSet("allowed", emptySet()) ?: emptySet()
}

data class Task(
    val text: String,
    val done: Boolean = false,
    val why: String = "",
    val daily: Boolean = false
)

data class Entry(val date: String, val min: Int, val note: String)

data class Goal(val title: String, val logs: List<Entry> = emptyList())

/** Planner ka data. JSON string ke roop me SharedPreferences me save hota hai. */
object Data {
    private fun fmt() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun today(): String = fmt().format(Date())

    fun dayAgo(n: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -n)
        return fmt().format(c.time)
    }

    // ---------- roz ka routine (template) ----------
    fun routine(p: SharedPreferences): List<String> {
        val a = JSONArray(p.getString("routine", "[]"))
        return List(a.length()) { a.getString(it) }
    }

    fun saveRoutine(p: SharedPreferences, l: List<String>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        p.edit().putString("routine", a.toString()).apply()
    }

    // ---------- din ke kaam ----------
    fun tasks(p: SharedPreferences, date: String): List<Task> {
        val raw = p.getString("tasks_$date", null)
        if (raw == null) {
            if (date != today()) return emptyList()
            // Naya din: routine ke kaam apne aap aa jaate hain.
            val seeded = routine(p).map { Task(it, daily = true) }
            saveTasks(p, date, seeded)
            return seeded
        }
        val a = JSONArray(raw)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Task(o.getString("t"), o.optBoolean("d"), o.optString("w"), o.optBoolean("r"))
        }
    }

    fun saveTasks(p: SharedPreferences, date: String, l: List<Task>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject()
                    .put("t", it.text)
                    .put("d", it.done)
                    .put("w", it.why)
                    .put("r", it.daily)
            )
        }
        p.edit().putString("tasks_$date", a.toString()).apply()
    }

    // ---------- saal ke lakshya ----------
    fun goals(p: SharedPreferences): List<Goal> {
        val a = JSONArray(p.getString("goals", "[]"))
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val l = o.optJSONArray("l") ?: JSONArray()
            Goal(
                o.getString("t"),
                List(l.length()) { j ->
                    val x = l.getJSONObject(j)
                    Entry(x.getString("d"), x.optInt("m"), x.optString("n"))
                }
            )
        }
    }

    fun saveGoals(p: SharedPreferences, gs: List<Goal>) {
        val a = JSONArray()
        gs.forEach { g ->
            val l = JSONArray()
            g.logs.forEach {
                l.put(JSONObject().put("d", it.date).put("m", it.min).put("n", it.note))
            }
            a.put(JSONObject().put("t", g.title).put("l", l))
        }
        p.edit().putString("goals", a.toString()).apply()
    }

    // ---------- Reel / Shorts counter ----------
    fun reels(p: SharedPreferences, date: String): Pair<Int, Int> =
        p.getInt("cy_$date", 0) to p.getInt("ci_$date", 0)

    fun addReel(p: SharedPreferences, youtube: Boolean) {
        val k = (if (youtube) "cy_" else "ci_") + today()
        p.edit().putInt(k, p.getInt(k, 0) + 1).apply()
    }

    fun weekReels(p: SharedPreferences): Int =
        (0..6).sumOf { i ->
            val r = reels(p, dayAgo(i))
            r.first + r.second
        }

    // ---------- Whole progress as one text for Claude ----------
    fun export(p: SharedPreferences): String {
        val sb = StringBuilder()
        sb.append(
            "Here is my plan and progress. Read it carefully first. " +
                "Then ask me short questions one by one (what is going on, where am I stuck), " +
                "and help me plan what to do next.\n\n"
        )
        sb.append("== YEARLY GOALS ==\n")
        val gs = goals(p)
        if (gs.isEmpty()) sb.append("(no goals written yet)\n")
        gs.forEach { g ->
            val total = g.logs.sumOf { it.min }
            val days = g.logs.map { it.date }.distinct().size
            sb.append("- ${g.title}: total ${total / 60}h ${total % 60}m over $days days\n")
            g.logs.takeLast(10).forEach {
                sb.append("    ${it.date}: ${it.min} min - ${it.note}\n")
            }
        }
        sb.append("\n== LAST 7 DAYS OF TASKS ==\n")
        for (i in 0..6) {
            val d = dayAgo(i)
            val t = tasks(p, d)
            if (t.isEmpty()) continue
            sb.append("$d (${t.count { it.done }}/${t.size} done)\n")
            t.forEach {
                val mark = if (it.done) "x" else " "
                val why = if (!it.done && it.why.isNotBlank()) " -- why not done: ${it.why}" else ""
                sb.append("  [$mark] ${it.text}$why\n")
            }
        }
        val r = reels(p, today())
        sb.append("\n== SHORTS/REELS WATCHED ==\n")
        sb.append("Today: ${r.first + r.second} (YouTube ${r.first}, Instagram ${r.second}); last 7 days: ${weekReels(p)}\n")
        return sb.toString()
    }
}
